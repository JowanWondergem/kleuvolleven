<?php 
if( !defined( 'ABSPATH') && !defined('WP_UNINSTALL_PLUGIN') )
	exit();

//global $wpdb;
//$usquare_table = $wpdb->base_prefix . 'usquare';
//$wpdb->query( "DROP TABLE $usquare_table" );
/*  
	If user remove plugin in order to upgrade it - it is not smart to delete plugin data :-)
*/
?>